﻿using Microsoft.Data.SqlClient;

namespace DecisionTree.Logging.DataAccess
{
    public class Data
    {
        public static void StoringData(string ErrorCode, string DataInfo)
        {
            int DataId = 0;
            SqlConnection con = new SqlConnection(@"Server=tcp:decisiontree-database-server.database.windows.net,1433;Initial Catalog=DecisionTreeDatabase;Persist Security Info=False;User ID=Wolskeet;Password={your_password};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            con.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT MAX(DataId) FROM data", con))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        DataId = reader.GetInt32(0) + 1;
                    }

                }
                reader.Close();
            }

            SqlCommand log = new SqlCommand(@"INSERT INTO [dbo].[data] ([DataId],[DataName],[DataInfo])
            VALUES ('" + DataId + "' , '" + ErrorCode + "' , '" + DataInfo + "')", con);
            log.ExecuteNonQuery();
            con.Close();
        }
    }
}