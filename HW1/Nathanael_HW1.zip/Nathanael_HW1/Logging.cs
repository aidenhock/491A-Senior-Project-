﻿using DecisionTree.Logging.DataAccess;

namespace DecisionTree.Logging
{
    public class DataLogging
    {
        public static void LogFormatting(string Error)
        {
            char[] separator = new char[] { '\n' };
            String[] log = Error.Split('\n');
            Data.StoringData(log[0], log[1]);
        }
    }
}
