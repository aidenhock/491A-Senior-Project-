﻿// See https://aka.ms/new-console-template for more information

using DecisionTree.Logging;

DataLogging.LogFormatting("Error Code: 1\n Email is already registered.");