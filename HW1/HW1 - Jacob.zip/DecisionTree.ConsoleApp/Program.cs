﻿// See https://aka.ms/new-console-template for more information
using DecisionTree.Logging;

//Test Case to Create a Log and add it into the table in our database
Logging.CreateLog("Error Code: 1\n" +
    "Email is already registered.");

