﻿using DecisionTree.DataAccess;

namespace DecisionTree.Logging
{
    public class Logging
    {
        //Creates a separate info to be inputted into the table from a single Error output
        public static void CreateLog(string Log)
        {
            //Separates between new lines
            char[] separator = { '\n' };
            //Splits the string into separate parts
            String[] LogInfo = Log.Split(separator);
            
            //Runs the data insertion method using the info we separated
            Data.DataInsertion(LogInfo[0], LogInfo[1]);
        }
    }
}