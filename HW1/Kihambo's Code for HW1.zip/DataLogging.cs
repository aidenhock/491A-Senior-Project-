﻿using DecisionTree.Logging;
using DecisionTree.Logging.DataAccess;

namespace DecisionTree.Logging
{
    public class DataLogging
    {
        public static void LogFormatting(string Error) //catches an error and returns a string
        {
            char[] separator = new char[] { '\n' };
            //separates characters to put into each array element

            String[] log = Error.Split('\n');
            //splits up the two strings

            Data.StoringData(log[0], log[1]);
        }

    }
}



