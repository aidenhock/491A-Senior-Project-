﻿
using DecisionTree.Logging;

DataLogging.LogFormatting("Error Code: 1\n Email is already registered."); //error message dsiplayed