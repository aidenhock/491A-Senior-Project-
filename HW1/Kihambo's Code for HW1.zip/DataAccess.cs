﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using MySql.Data.MySqlClient; //libraries

namespace DecisionTree.Logging.DataAccess

{
    public class Data
    { 

        public static void StoringData(string errorCode, string dataInfo)
        {
                int dataID = 0; //initialize the id to 0 for later use

        MySqlConnection c = new MySqlConnection(@"Server=tcp:kihambo.database.windows.net,1433;Initial Catalog=Kihambo;Persist Security Info=False;User ID=Kihambo;Password={your_password};
                                                MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"); //my sql information to
                                                                                                                          //connect VS to the DB
            
            c.Open(); //opens sqlconnection

            using (MySqlCommand cmd = new MySqlCommand("SELECT MAX(DataID) FROM data", c))

            {
                MySqlDataReader r = cmd.ExecuteReader(); //reads execution

                if (r != null) //just in case there's nothing/ empty space
                {
                    while (r.Read())
                    {
                        dataID = r.GetInt32(0) + 1;
                    }
                    r.Close(); //closes reader
                }
            }
            MySqlCommand log = new MySqlCommand(@"INSERT INTO First_Table (numbers, digits, integers) VALUES: (@74, @0, @0)"); //where values are inserted
       
            log.ExecuteNonQuery();

            c.Close();//closes mysql connection
        }

    }
}