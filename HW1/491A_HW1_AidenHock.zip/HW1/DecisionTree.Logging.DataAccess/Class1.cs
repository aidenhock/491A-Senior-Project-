﻿//console app is dependent on logging => logging is dependent on data access => data access is dependent on dotnet add package System.Data.SqlClient

using System.Data.SqlClient;

namespace DecisionTree.Logging.DataAccess
{
    public class Data
    {
        public static void StoringData(string ErrorCode, string DataInfo)
        {
            int DataId = 0;

            //using connection string (main way to connect to db)
            SqlConnection con = new SqlConnection(@"Server=LAPTOP-K4K9FK44; Database=musical_logging; User Id=aidenhock; Password=1234; TrustServerCertificate=True; Trusted_Connection=True;");
            con.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT MAX(DataId) FROM Data", con))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        Console.Write(reader.GetInt32(0));
                        DataId = reader.GetInt32(0) + 1;
                    }

                }
                reader.Close();
            }
            //credit kameron f. for helping me set up the table and connect to the sql server. DataId,DataName, and DataInfo are his table column names
            SqlCommand log = new SqlCommand(@"INSERT INTO [dbo].[Data] ([DataId],[DataName],[DataInfo])
            VALUES ('" + DataId + "' , '" + ErrorCode + "' , '" + DataInfo + "')", con);
            log.ExecuteNonQuery();
            con.Close();
        }
    }
}