﻿using System.Data.SqlClient;

namespace DecisionTree.Logging.DataAccess
{
    public class DataAccessClass
    {
        public static void StoringData(string ErrorCode, string DataInfo)
        {
            int DataId = 0;
            string connectString = "Server = tcp:decisiontree491.database.windows.net,1433; Initial Catalog = DecisionTree; Persist Security Info = False; User ID = stuhgo; Password = Syzygy899; MultipleActiveResultSets = False; Encrypt = True; TrustServerCertificate = False; Connection Timeout = 30;";
            SqlConnection con = new SqlConnection(connectString);
            con.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT MAX(DataId) FROM data", con))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        DataId = reader.GetInt32(0) + 1;
                    }

                }
                reader.Close();
            }

            SqlCommand log = new SqlCommand(@"INSERT INTO [dbo].[data] ([DataId],[DataName],[DataInfo])
            VALUES ('" + DataId + "' , '" + ErrorCode + "' , '" + DataInfo + "')", con);
            log.ExecuteNonQuery();
            con.Close();
        }
    }
}