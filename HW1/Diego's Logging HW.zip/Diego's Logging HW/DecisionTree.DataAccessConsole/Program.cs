﻿// See https://aka.ms/new-console-template for more information

using DecisionTree.Logging;

LoggingClass.LogFormatting("Error Code: 1\n Email is already registered.");